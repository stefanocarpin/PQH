#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h> 
#include "libqhull/qhull_a.h"
#include "libqhull/libqhull.h"
#include "libqhull/qset.h"

#define DIM 6

struct Result{
        double Qdis;
        int PA;
        int HPC;
        double Time;
};

struct Weight{
	int ind;
	double w;
};

double Dot(double *a,double *b, int DIMi)
{
  double dotp=0.0;
  int i;
  for(i=0;i<DIMi;i++)
  {
    dotp=dotp+a[i]*b[i];
  }
  return dotp;
}

int comp(const void *a,const void *b)
{
	double rst=((struct Weight*)b)->w-((struct Weight*)a)->w;
	return (rst>=0)?1:(-1);
} 



struct Result Qdis (char *Filename1,char *Filename2,int PNUM, int PNUM2)
{
  struct Result FtR;
  FtR.Qdis=-1;
  FtR.PA=-1;
  FtR.HPC=-1;
  FtR.Time=-1;


  int i,j,k,l;
//Read Wows
  FILE* fp=fopen(Filename1,"r");
  double Points[PNUM][DIM];
  for(i=0;i<PNUM;i++)
  {
    for(j=0;j<DIM;j++)
    {
      double fs;
      fscanf(fp,"%lf",&fs);
      Points[i][j]=fs;
    }
  }
  fclose(fp);
//Read Wgws
  fp=fopen(Filename2,"r");
  double Points2[PNUM2][DIM];
  for(i=0;i<PNUM2;i++)
  {
    for(j=0;j<DIM;j++)
    {
      double fs;
      fscanf(fp,"%lf",&fs);
      Points2[i][j]=fs;
    }
  }
  fclose(fp);

  struct timezone tz;
  struct timeval tvstart;
  gettimeofday(&tvstart,&tz);
  coordT *Nwspace= malloc((PNUM)*DIM* sizeof(coordT)); 

  for(i=0;i<PNUM;i++)
  {
    for(j=0;j<DIM;j++)
    {
      Nwspace[i*DIM+j]=Points[i][j];
      
    }
  }
  //qh insideCHpoints= malloc((PNUM2)*DIM* sizeof(coordT));
  coordT *Nwspace2= malloc((PNUM2)*DIM* sizeof(coordT));

  for(i=0;i<PNUM2;i++)
  {
    for(j=0;j<DIM;j++)
    {
      //qh insideCHpoints[i*DIM+j]=Points2[i][j];
      Nwspace2[i*DIM+j]=Points2[i][j];
    }
  }
//  qh num_insideCHpoints=PNUM2;

  char *flags=malloc(2500 * sizeof(char));          /* option flags for qhull, see qh-quick.htm */
  FILE *outfile= NULL;    /* output from qh_produce_output()
                               use NULL to skip qh_produce_output() */
  FILE *errfile= stderr; //fopen("error.log","a");    /* error messages from qhull code */
  int exitcode;
  facetT *facet,*facett;            /* set by FORALLfacets */
  vertexT *vertex, **vertexp;
  int curlong, totlong;     /* memory remaining after qh_memfreeshort */
  sprintf (flags, "qhull Qt Pp");
  exitcode=qh_new_qhull_ows (DIM, PNUM, Nwspace, PNUM2, Nwspace2, 0,flags, outfile, errfile);
  //printf ("\n%d vertices and %d facets with normals:\n",qh num_vertices, qh num_facets);
  if(exitcode!=0)
  {
    qh_freeqhull(!qh_ALL);                   /* free long memory  */
    qh_memfreeshort (&curlong, &totlong);    /* free short memory and memory*/
    free(Nwspace);
    //free(flags);
    free(flags);
    return FtR;
  }


  struct timeval tvend;
  gettimeofday(&tvend,&tz);
  struct Result QR;
  QR.Qdis=qh minir;
  QR.PA=qh num_vertices;
  QR.HPC=qh num_facets;
  QR.Time=(double)(tvend.tv_sec - tvstart.tv_sec)*1000+(double)(tvend.tv_usec - tvstart.tv_usec)/1000;
  qh_freeqhull(!qh_ALL);                   /* free long memory  */
  qh_memfreeshort (&curlong, &totlong);    /* free short memory and memory*/
  free(Nwspace);
  free(Nwspace2);
  free(flags);
  return QR;
}

int main ()
{
   double min=-10.0;
   struct Result QR;
   char Filename[50];
   char Filename2[50];
   char Resultpath[50];
   FILE *fp;
   sprintf(Filename2,"Wows.txt");
   int i;
   sprintf(Resultpath,"Result.txt");
   fp=fopen(Resultpath,"w");
   for(i=0;i<200;i++)   
   {
     sprintf(Filename,"../dataset_gws2/Wgws%d.txt",i+1);
     QR=Qdis(Filename,Filename2,32,1458);
     printf("Qows=%lf, Time=%lf\n",QR.Qdis,QR.Time);
     fprintf(fp,"%lf %lf\n",QR.Qdis,QR.Time);
   }
}

