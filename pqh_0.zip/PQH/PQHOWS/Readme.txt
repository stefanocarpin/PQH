In order to generate Figure 8 and 9 from the paper, please follow the instructions below:
Install PQHOWS lib.
Build and run CH.c inside PQHOWS folder.
Install PQHwNFC lib.
Build and run CH.c inside BruteForcePQH folder.
Install QHULL lib.
Build and run CH.c inside BruteForceQHULL folder.
Run Matlab code drawFig8and9.m.
