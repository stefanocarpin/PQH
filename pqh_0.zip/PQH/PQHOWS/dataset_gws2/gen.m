function gen()
M=importdata('../MatlabTest/obj.tris');
[v,fac]=read_ply('../MatlabTest/obj.ply');
Fnum=4;
Face=[];
COM=sum(M)/size(M,1);

for ii=1:200
    for i=1:Fnum
        j=mod(floor(rand()*1000),size(M,1)/3)+1;
        Face=[Face;M(j*3-2:j*3,:)];
    end
    
    for i=1:Fnum
        N(i,:)=[Face(i*3-2,2)*Face(i*3-1,3)-Face(i*3-2,2)*Face(i*3,3)-Face(i*3-1,2)*Face(i*3-2,3)+Face(i*3-1,2)*Face(i*3,3)+Face(i*3,2)*Face(i*3-2,3)-Face(i*3,2)*Face(i*3-1,3);...
            Face(i*3-2,3)*Face(i*3-1,1)-Face(i*3-2,3)*Face(i*3,1)-Face(i*3-1,3)*Face(i*3-2,1)+Face(i*3-1,3)*Face(i*3,1)+Face(i*3,3)*Face(i*3-2,1)-Face(i*3,3)*Face(i*3-1,1);...
            Face(i*3-2,1)*Face(i*3-1,2)-Face(i*3-2,1)*Face(i*3,2)-Face(i*3-1,1)*Face(i*3-2,2)+Face(i*3-1,1)*Face(i*3,2)+Face(i*3,1)*Face(i*3-2,2)-Face(i*3,1)*Face(i*3-1,2);];
        N(i,:)=N(i,:)/norm(N(i,:));
    end
    mu=0.3;
    fangle=atan(mu);
    friction=zeros(3,3);
    
    CN=8;
    contacts=zeros(3,3);
    ch=zeros(3*CN,3);
    torq=zeros(3*CN,3);
    wspace=zeros(3*CN,6);
    for i=1:Fnum
        if N(i,1)*N(i,2)*N(i,3)==0
            for j=1:3
                if N(i,j)==0
                    friction(i,j)=1;
                    break;
                end
            end
        else
            friction(i,1)=-N(i,2);
            friction(i,2)=N(i,1);
            friction(i,:)=(friction(i,:)/norm(friction(i,:)));
        end
        RotM(:,:,i)=[N(i,:);friction(i,:);cross(N(i,:),friction(i,:))];
    end
    for i=1:Fnum
        fi=0;
        step=2*pi/CN;
        for j=1:CN
            fc(:,j,i)=N(i,:)+tan(fangle).*[0,cos(fi),sin(fi)]*RotM(:,:,i);
            %plot3(x,y,z,'g');
            fi=fi+step;
        end
    end
    
    alpha=zeros(Fnum,2);
    alpha(:,1)=rand(Fnum,1);
    alpha(:,2)=(1-alpha(:,1)).*rand(Fnum,1);
    for i=1:Fnum
        contacts(i,:)=alpha(i,1)*(Face(i*3-2,:)-Face(i*3,:))+alpha(i,2)*(Face(i*3-1,:)-Face(i*3,:))+Face(i*3,:);
    end
    for i=1:Fnum
        for j=1:CN
            ch(i*CN+j-CN,:)=fc(:,j,i);
            torq(i*CN+j-CN,:)=cross(contacts(i,:)-COM,fc(:,j,i));
        end
    end
    for i=1:CN*Fnum
        wspace(i,:)=[ch(i,:),torq(i,:)];
    end
    %K = convhulln(torq);
    %trisurf(K,torq(:,1),torq(:,2),torq(:,3))
    
    %%%convexhull computation
    k=convhulln(wspace, {'Qt','Qx'});
    [Normal6,offset]=FindNormal6(k,wspace);
    flag=0;
    for i=1:size(k,1)
        if offset(i)>0&&~isnan(offset(i))
            flag=1;
        end
    end
    if flag==0
        str=sprintf('Wgws%d.txt',ii);
        save ( str, 'wspace','-ascii');
    else
        ii=ii-1;
    end
    
end


function [Normal6,offset]=FindNormal6(k,wspace)
Normal6=zeros(size(k));
offset=zeros(size(k,1),1);
center=mean(wspace,1);
for i=1:size(k,1)
    nsp = null(wspace(k(i,2:end),:) - repmat(wspace(k(i,1),:),6-1,1))';
    if size(nsp,1)>1
        size(nsp,1);
        Normal6(i,:) = NaN;
    else
        Normal6(i,:)=nsp(1,:);
    end
    Normal6(i,:)=Normal6(i,:)/norm(Normal6(i,:));
    if dot(center-wspace(k(i,1),:),Normal6(i,:))<0
        Normal6(i,:)=-Normal6(i,:);
    end
    offset(i)=dot(wspace(k(i,1),:),Normal6(i,:));
end