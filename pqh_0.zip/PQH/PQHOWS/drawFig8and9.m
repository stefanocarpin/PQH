clear all;close all;
lw = 3;
fs = 15;

QH1=importdata('PQHOWS/Result.txt');
PQH1=importdata('BruteForceQHULL/ResultQH.txt');
PQH2=importdata('BruteForcePQH/ResultPQH.txt');
h=figure(1);

plot(QH1(:,2),'b-','Linewidth',lw); 
hold on;    
grid on
plot(PQH1(:,2),'g-.','Linewidth',lw); 
hold on;    
grid on
plot(PQH1(:,3),'r-.','Linewidth',lw); 
hold on;    
grid on
plot(PQH2(:,2),'c-.','Linewidth',lw); 
ylabel('Time(ms)','Fontsize',fs);
d=QH1(:,1)-PQH1(:,1);
xlabel('Number of Episodes','Fontsize',fs);
  h = legend('$PQ_{OWS}$','QuickHull','Brute Force','Partial QuickHull');
  set(h,'Interpreter','latex')
figure(2)
%plot(PQH1(:,1),'g-.','Linewidth',lw); 
hold on;    
grid on
for i=1:200
    R(i)=(PQH1(i,4)-PQH1(i,1))/PQH1(i,1);
end
plot(R,'r-.','Linewidth',lw); 
ylabel('Quality Measure','Fontsize',fs);
xlabel('Number of Episodes','Fontsize',fs);

