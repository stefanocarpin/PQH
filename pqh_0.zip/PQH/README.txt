*******************************************************************************
Copyright (c), The Regents of the University of California.
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the The Regents of the University of California nor 
      the names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OF 
THE UNIVERSITY OF CALIFORNIA AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************

Note: this code has been developed an tested in Linux (Ubuntu 14.04). 
While it should work also with other Unix flavors, no tests have been
done.

Installation instructions
-------------------------
This package includes two different patches to generate two algorithms
for two different grasp quality metrics.

PQHGWS - Partial QuickHull for Grasp Wrench Space
-------------------------------------------------
PQHGWS accerlerates the computation of the grasp quality metric proposed
by Ferrari and Canny in their 1992 ICRA paper,

Ferrari, C.; Canny, John, "Planning optimal grasps," Robotics and Automation, 
1992. Proceedings., 1992 IEEE International Conference on, 
vol., no., pp.2290,2295 vol.3, 12-14 May 1992.

Most implementations to compute this metric use the QuickHull library.
PQHGWS patches QuickHull so that the computation stops as soon 
as the metric can be determined. A 20x speedup is typical, and often
times an even larger gain is observer. If you use our implementation, please
cite the following paper,

Liu, S. ; Carpin, S., "Fast grasp quality evaluation with partial convex 
hull computation," Robotics and Automation (ICRA), 2015 IEEE International 
Conference on , vol., no., pp.4279,4285, 26-30 May 2015

To install the patch:

1- download the QuickHull library from http://www.qhull.org/download/.
Select Qhull 2012.1 for Unix http://www.qhull.org/download/qhull-2012.1-src.tgz
and unzip it.

2- copy the file PQHGWS.patch into the QHull's installation directory, move
into that folder and run  

patch -p0 < PQHGWS.patch

3- build QHull following the instructions provided with the library.

4- that is it. To compute the metric just build the convex hull of the
elementary wrenches as you would do using QHull. The output is 
-qh Offsetfrom0. It the value is positive, the grasp is force closure
and the value is the Ferrari-Canny metric. If the value is negative, 
the grasp is not force closure and the value is the distance of the
origin from the convex hull. See also the example file in 
PQHGWS.example for more details.

Important: the paper cited above presents an algorithm that accellerates
the computation only when the grasp is force closure, whereas the
current implementation is better because it accellerates the computation
in both cases. The improved version is currently under review for
the IEEE Transactions on Automation Science and Engineering.

Liu, S.; Carpin, S. , "Partial Convex Hull Algorithms for Efficient Grasp 
Quality Evaluation ", Automation Science and Engineering, IEEE Transactions 
on, (under review). 

PQHOWS - Partial QuickHull for Objct Wrench Space
-------------------------------------------------
PQHOWS accelerates the computation of the grasp metric proposed in 

Strandberg, M.; Wahlberg, B., "A method for grasp evaluation based on 
disturbance force rejection," Robotics, IEEE Transactions on , vol.22, 
no.3, pp.461,469, June 2006

Please refer to the following paper for details:

Shuo Liu; Carpin, S., "A Fast Algorithm for Grasp Quality Evaluation  
Using the Object Wrench Space," Automation Science and Engineering (CASE), 
2015 IEEE International Conference on , August 2015 (to appear)

To install the patch:

1- download the QuickHull library from http://www.qhull.org/download/.
Select Qhull 2012.1 for Unix http://www.qhull.org/download/qhull-2012.1-src.tgz
and unzip it.

2- copy the file PQHOWS.patch into the QHull's installation directory, move
into that folder and run  

patch -p0 < PQHOWS.patch

3- build QHull following the instructions provided with the library.

4- that is it. See also the example file in PQHGWS.example for details
on how to use it.



Data Files
----------
The tarball includes also the data files and scripts to reproduce the
results presented in the aforementioned paper currently under revision
for TASE. Note that to run these tests you will also need the GNU
Scientific Library (aka GSL).

To replicate the results presented in figure 6 and 7 follow the following
instructions. Note that these tests require you to run both the original
and the patched QuickHull library. For simplicity we suggest you to 
just reinstall QHull when needed, but you can obviously have both installed
at the same time, provided you make the necessary changes to the makefiles.

For Figure 6 and 7:

1- Install the original QuickHull library.
2- Edit CH.c inside the PQHGWS/QHULL folder and uncomment the main function for
Figure 6. Build it using the provided makefile and run it.
3- create the PQHGWS library as per the above instructions and install it.
4- Edit CH.c inside the PQHGWS/PQHGWS folder and uncomment the main function for
Figure 6. Build it using the provided makefile and run it.
5- Run the matlab script drawFig6.m

To create figure 7, repeat the same steps, but uncomment the main functions
marked for Figure 7 and at the end run the script drawFig7.m

For Figure 8 and 9:

1- Install the original QuickHull library
2- Go into PQHOWS/BruteForceQHULL, type make, and run the executable CH.
3- Create the PQHOWS library as per the above instructions and install it.
4- Go into PQHOWS/BruteForcePQH, type make, and run the executable CH.
5- Run the matlab script drawFig8and9.m
