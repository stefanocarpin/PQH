In order to generate Figure 6 and 7 from the paper, please follow the instructions below.
Figure 6:
Install PQHwNFC lib.
Open CH.c inside PQHNFC folder, uncomment the main function for Figure 6.
Build and run CH.
Install QHULL lib.
Open CH.c inside QHULL folder, uncomment the main function for Figure 6.
Build and run CH.
Run Matlab code drawFig6.m.
Figure 7:
Install PQHwNFC lib.
Open CH.c inside PQHNFC folder, uncomment the main function for Figure 7.
Build and run CH.
Install QHULL lib.
Open CH.c inside QHULL folder, uncomment the main function for Figure 7.
Build and run CH.
Run Matlab code drawFig7.m.
