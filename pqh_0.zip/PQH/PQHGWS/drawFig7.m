clear all;close all;
QH1=importdata('QHULL/ResultFCnumvaryNFC.txt');
PQH1=importdata('PQHNFC/ResultFCnumvaryNFC.txt');
lw = 2;
fs = 20;
x=8:2:64;
Cnum=200;
for i=1:29
    Pratio(i)=mean(QH1(i*Cnum-Cnum+1:i*Cnum,2))/mean(PQH1(i*Cnum-Cnum+1:i*Cnum,2));
    Hratio(i)=mean(QH1(i*Cnum-Cnum+1:i*Cnum,3))/mean(PQH1(i*Cnum-Cnum+1:i*Cnum,3));
end
figure(1)
plot(x,Pratio,'r-.','Linewidth',lw); 
hold on;    
grid on
ylabel('Points','Fontsize',fs);
xlabel('Number of edges','Fontsize',fs);
figure(2)
plot(x,Hratio,'r-.','Linewidth',lw); 
hold on;    
grid on
ylabel('Hyperplanes','Fontsize',fs);
xlabel('Number of edges','Fontsize',fs);