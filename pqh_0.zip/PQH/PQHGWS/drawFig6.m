close all; clear all;
lw = 2;
fs = 20;
PQH1=importdata('PQHNFC/Resultrdmgrasp.txt');
QH1=importdata('QHULL/Resultrdmgrasp.txt');
h=figure(1);
%Plot Value from data
subplot(2,3,1);
p = gca(h);
set(p,'FontSize',fs)
grid on
plot(QH1(:,2),'b-.','Linewidth',lw); 
hold on;    
grid on
plot(PQH1(:,2),'g-.','Linewidth',lw); 
ylabel('Points','Fontsize',fs);

subplot(2,3,2);
p = gca(h);
set(p,'FontSize',fs)
plot(QH1(:,3),'b-.','Linewidth',lw);
hold on;    
grid on
plot(PQH1(:,3),'g-.','Linewidth',lw); 
ylabel('Hyperplanes','Fontsize',fs);


subplot(2,3,3);
p = gca(h);
set(p,'FontSize',fs)
plot(QH1(:,4),'b-.','Linewidth',lw);
hold on;    
grid on
plot(PQH1(:,4),'g-.','Linewidth',lw); 
ylabel('Time(ms)','Fontsize',fs);

%Plot ratio
for i=1:200
    ratio(i,1)=QH1(i,2)/PQH1(i,2);
    ratio(i,2)=QH1(i,3)/PQH1(i,3);
    ratio(i,3)=QH1(i,4)/PQH1(i,4);
end

subplot(2,3,4);
p = gca(h);
set(p,'FontSize',fs)
plot(ratio(:,1),'r-.','Linewidth',lw); 
grid on;
ylabel('Points','Fontsize',fs);


subplot(2,3,5);
p = gca(h);
set(p,'FontSize',fs)
plot(ratio(:,2),'r-.','Linewidth',lw); 
grid on;
ylabel('Hyperplanes','Fontsize',fs);

subplot(2,3,6);
p = gca(h);
set(p,'FontSize',fs)
plot(ratio(:,3),'r-.','Linewidth',lw); 
grid on;
ylabel('Time(ms)','Fontsize',fs);