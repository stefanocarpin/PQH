#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/time.h> 
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_statistics.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include "libqhull/qhull_a.h"
#include "libqhull/libqhull.h"
#include "libqhull/qset.h"

#define DIM 6

struct Face{
	gsl_vector *Normal;
        int *Pset;
        int Vnum;
//        int *Vset;
        double Qdis;
        int MaxShiftInd;
};

struct Vertex{
        int *Fset;
        int Fnum;
};


struct Result{
        double Qdis;
        int PA;
        int HPC;
        double Time;
};

struct Weight{
	int ind;
	double w;
};

double Dot(double *a,double *b, int DIMi)
{
  double dotp=0.0;
  int i;
  for(i=0;i<DIMi;i++)
  {
    dotp=dotp+a[i]*b[i];
  }
  return dotp;
}

int comp(const void *a,const void *b)
{
	double rst=((struct Weight*)b)->w-((struct Weight*)a)->w;
	return (rst>=0)?1:(-1);
} 



struct Result Qdis (char *argv,int PNUM)//1:File Path
{
  FILE* fp=fopen(argv,"r");
  struct Result FtR;
  FtR.Qdis=-1;
  FtR.PA=-1;
  FtR.HPC=-1;
  FtR.Time=-1;


  int i,j,k,l;

  double Points[PNUM][DIM];
  for(i=0;i<PNUM;i++)
  {
    for(j=0;j<DIM;j++)
    {
      double fs;
      fscanf(fp,"%lf",&fs);
      Points[i][j]=fs;
    }
  }
  fclose(fp);

  struct timezone tz;
  struct timeval tvstart;
  gettimeofday(&tvstart,&tz);
  coordT *Nwspace= malloc((PNUM)*DIM* sizeof(coordT)); 

  for(i=0;i<PNUM;i++)
  {
    for(j=0;j<DIM;j++)
    {
      Nwspace[i*DIM+j]=Points[i][j];
      
    }
  }

  char *flags=malloc(2500 * sizeof(char));          /* option flags for qhull, see qh-quick.htm */
  FILE *outfile= NULL;    /* output from qh_produce_output()
                               use NULL to skip qh_produce_output() */
  FILE *errfile= stderr; //fopen("error.log","a");    /* error messages from qhull code */
  int exitcode;
  facetT *facet;            /* set by FORALLfacets */
  vertexT *vertex, **vertexp;
  int curlong, totlong;     /* memory remaining after qh_memfreeshort */
  sprintf (flags, "qhull Qt");
  exitcode=qh_new_qhull (DIM, PNUM, Nwspace, 0,flags, outfile, errfile);
  //printf ("\n%d vertices and %d facets with normals:\n",qh num_vertices, qh num_facets);
  if(exitcode!=0)
  {
    qh_freeqhull(!qh_ALL);                   /* free long memory  */
    qh_memfreeshort (&curlong, &totlong);    /* free short memory and memory*/
    free(Nwspace);
    //free(flags);
    free(flags);
    return FtR;
  }
  
  struct timeval tvend;
  gettimeofday(&tvend,&tz);
  struct Result QR;
  QR.Qdis=-qh OffsetfromO;
  QR.PA=qh num_vertices;
  QR.HPC=qh num_facets;
  QR.Time=(double)(tvend.tv_sec - tvstart.tv_sec)*1000+(double)(tvend.tv_usec - tvstart.tv_usec)/1000;
  qh_freeqhull(!qh_ALL);                   /* free long memory  */
  qh_memfreeshort (&curlong, &totlong);    /* free short memory and memory*/
  free(Nwspace);
  free(flags);
  return QR;
}

//grasp test 200: Result used to Generate Figure 6 in the paper
/*
int main ()
{
   int i,j;
   double min=-10.0;
   struct Result QR;
   char Filename[50];
   char Resultpath[50];
   FILE *fp;
   sprintf(Resultpath,"Resultrdmgrasp.txt");
   fp=fopen(Resultpath,"w");
   for(j=0;j<200;j++)
   {
     sprintf(Filename,"../Dataset3/CTN4FCN32MU0.5Set%d.txt",j+1);
     QR=Qdis(Filename,128);
     fprintf(fp,"%.10lf %d %d %lf\n",QR.Qdis,QR.PA,QR.HPC,QR.Time);
     printf("Result:%.10lf %d %d %lf\n",QR.Qdis,QR.PA,QR.HPC,QR.Time);
   }
   fclose(fp);
   return 0;
}
*/


//grasp test fcnum: Result used to Generate Figure 7 in the paper
/*
int main ()
{
fclose(stderr);
   int i,j;
   double min=-10.0;
   struct Result QR;
   char Filename[50];
   char Resultpath[50];
   FILE *fp;
   sprintf(Resultpath,"ResultFCnumvaryNFC.txt");
   fp=fopen(Resultpath,"w");
   for(j=8;j<=64;j=j+2) 
   {
     for(i=0;i<200;i++)
     {
       sprintf(Filename,"../DatasetFCNFC/CTN4FCN%dMU0.5Set%d.txt",j,i+1);
       QR=Qdis(Filename,j*4);
       fprintf(fp,"%.10lf %d %d %lf\n",QR.Qdis,QR.PA,QR.HPC,QR.Time);
     }
   }
   fclose(fp);
   return 0;
}

*/
